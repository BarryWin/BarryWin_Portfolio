# SmoothScroll.js
A simple smooth scrolling using 100% vanilla JavaScript.

Live view : http://tiiim.fr/assets/projects/smoothScroll/
